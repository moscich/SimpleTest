#import <Foundation/Foundation.h>

@interface MQRateNow :NSObject

+ (void)startWithAppId:(NSString *)appId;

@end