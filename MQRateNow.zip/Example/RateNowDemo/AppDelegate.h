//
//  AppDelegate.h
//  RateNowDemo
//
//  Created by Marek Mościchowski on 07/01/16.
//  Copyright © 2016 Miquido. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

