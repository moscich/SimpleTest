//
//  ViewController.h
//  RateNowDemo
//
//  Created by Marek Mościchowski on 07/01/16.
//  Copyright © 2016 Miquido. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

